
package voteandeat;
import static java.lang.Integer.parseInt;
import java.sql.*;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @NSBM FOOD ORDERING AND VOTING SYSTEM 
 */
public class DatabaseClass extends DateTimeConversions
{
    Connection con;
    Statement stmt;
    private static int activeNsbmId;
    private static String activeCanteen;
    private static int activeCanteenNo;
    
    
//METHOD TO OPEN DATABASE CONNECTION
     public void openConn()
    {
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            //SET THE DATABASE PASSWORD IN THE BELOW CODE
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/voteandordersystem","root","");
            
            
        }
        catch (ClassNotFoundException | SQLException e)
        {
            JOptionPane.showMessageDialog(null,"Invalid Entry\n(" + e + ")");
        }
    }     
     
//METHOD TO CLOSE DATABASE CONNECTION
     public void closeConn()
    {
        try {
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(DatabaseClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }     
     
//METHOD TO ENTER VALUES INTO VOTE-VALIDATING TABLE   
    public void insertIntoVoteValidating()
    {
        try {
            getCanteenNo();
            stmt = con.createStatement();
            stmt.execute("INSERT INTO votevalidating(NSBMID,CanteenNo,Date)VALUES("+getActiveNsbmId()+","+getActiveCanteenNo()+",'"+getDateStr()+"')");
        } 
        catch (SQLException ex)
        {
           JOptionPane.showMessageDialog(null,"Invalid Entry\n(" + ex + ")");
            
        }

    }
    
//METHOD TO RETURN OPTION NAME IF RADIO BUTTON IS SELECTED
    public String selectedRadioButton3o(JRadioButton button1, JRadioButton button2,
            JRadioButton button3, String option1, String option2, String option3)
    {
        
        if (button1.isSelected()) 
        {
            return option1;
        }
        
        else if (button2.isSelected())
        {
            return option2;
        }
        
        else if (button3.isSelected())
        {
            return option3;
        }
        return null;
    }
      
//METHOD TO GET 1 IF AN INT VALUE FROM FIELD BOX IS PRESENT IN A TABLE
    public int validateInt(String tableName,String fieldName, JTextField textFieldName)
    {
        try {
            stmt = con.createStatement();
            String SQL = "SELECT * FROM " + tableName;
            ResultSet rs = stmt.executeQuery(SQL);
            while(rs.next())
            {
                int value = rs.getInt(fieldName);
                if(value ==  parseInt(textFieldName.getText()))
                {
                    return 1;
                }
            }
        } 
        catch (NumberFormatException | SQLException ex) {
           JOptionPane.showMessageDialog(null,"Invalid Entry\n(" + ex + ")");
        }
        return 0;
  
    }
    
//METHOD TO CHECK IF A PERSON HAS ALREADY VOTED
    public int voteValidation(String tableName, String fieldName1, int value1,String fieldName2, int value2)
    {
        try 
        {
            stmt = con.createStatement();
            String SQL1 = "SELECT * FROM " + tableName;
            ResultSet rs1 = stmt.executeQuery(SQL1);
            while(rs1.next())
            {
                int valueA = rs1.getInt(fieldName1);
                if(valueA == value1)
                {
                    stmt = con.createStatement();
                    String SQL2 = "SELECT "+fieldName2+" FROM " + tableName + " WHERE "+fieldName1+" = '"+value1+"'";
                    ResultSet rs2 = stmt.executeQuery(SQL2);
                    while(rs2.next())
                    {
                        int valueB = rs2.getInt(fieldName2);
                        if(valueB == value2)
                        return 1;
                    }
                }
            } 
        }   
        catch (NumberFormatException | SQLException ex)
        {
           JOptionPane.showMessageDialog(null,"Invalid Entry\n(" + ex + ")");
            
        }
        return 0;
    }
    
//METHOD TO CHECK IF A STRING VALUE AND AN INT VALUE EXIST IN A TABLE
    public int validateDoubleValues(String tableName, String fieldName1, String value1,String fieldName2, int value2)
    {  
       
            try {
                stmt = con.createStatement();
                String SQL1 = "SELECT * FROM "+tableName+" WHERE "+fieldName1+" = '"+value1+"'";
                ResultSet rs1 = stmt.executeQuery(SQL1);
                while(rs1.next())
                {
                    int valueA = rs1.getInt(fieldName2);
                    if(valueA == value2)
                    {
                        return 1;
                    }
                }
            } catch (NumberFormatException | SQLException ex)
        {
           JOptionPane.showMessageDialog(null,"Invalid Entry\n(" + ex + ")");
            
        }
          
 
        return 0;
    }
           
//METHOD TO INSERT A VOTE
    public void insertVote(String name1, String name2, String name3, String name4,
    String name5, String name6)
    {
   
        if (validateDoubleValues("votecount", "PrepDate", getDateStr(),"CanteenNo", getActiveCanteenNo())==1) 
        {
            try {
                stmt = con.createStatement();
                String SQL = "SELECT * FROM votecount WHERE PrepDate = '" +getDateStr()+"' AND CanteenNo = "+getActiveCanteenNo();
                ResultSet rs = stmt.executeQuery(SQL);
                while(rs.next())
                {
                    int newValue1 = rs.getInt(name1)+1;
                    int newValue2 = rs.getInt(name2)+1;
                    int newValue3 = rs.getInt(name3)+1;
                    int newValue4 = rs.getInt(name4)+1;
                    int newValue5 = rs.getInt(name5)+1;
                    int newValue6 = rs.getInt(name6)+1;
                    
                    getCanteenNo();
                    stmt = con.createStatement();
                    stmt.execute("UPDATE votecount SET "
                            + ""+name1+" = "+newValue1
                            +","+name2+" = "+newValue2
                            +","+name3+" = "+newValue3
                            +","+name4+" = "+newValue4
                            +","+name5+" = "+newValue5
                            +","+name6+" = "+newValue6+" WHERE PrepDate = '" +getDateStr()+"' AND CanteenNo = "+getActiveCanteenNo());
                    
                }
            } catch (NumberFormatException | SQLException ex)
        {
           JOptionPane.showMessageDialog(null,"Invalid Entry\n(" + ex + ")");
            
        }
            
        }
        else
        {
            try {
                stmt = con.createStatement();
                stmt.execute("INSERT INTO votecount(PrepDate, CanteenNo) VALUES('"+getDateStr()+"',"+getActiveCanteenNo()+")");
                insertVote(name1, name2, name3, name4, name5, name6);
            } catch (NumberFormatException | SQLException ex)
        {
           JOptionPane.showMessageDialog(null,"Invalid Entry\n(" + ex + ")");
            
        }
        }
        
    }
    
//METHOD TO REMOVE A RECORD CONTAINING A INT VALUE
    public void removeSelected(String tableName, String header, int value)
    {
        try {
            stmt = con.createStatement();
            stmt.execute("DELETE FROM "+tableName+" WHERE "+header+" = "+value);
        } 
        catch (SQLException ex) 
        {
           JOptionPane.showMessageDialog(null,"Invalid Entry\n(" + ex + ")");
        }
    }
    
//METHOD TO REMOVE ALL RECORDS FROM A TABLE
    public void removeAllRecords(String tableName)
    {
        try {
            stmt = con.createStatement();
            stmt.execute("DELETE FROM "+tableName);
        } 
        catch (SQLException ex) 
        {
           JOptionPane.showMessageDialog(null,"Invalid Entry\n(" + ex + ")");
        }
    }
     
//METHOD TO ADD DETAILS TO CART
    public void insertIntoCart(String Rice,String Curry, int Quantity)
    {
        try 
        {
            String date = getDateStr();
            stmt = con.createStatement();
            stmt.execute("INSERT INTO cart(NSBMID, date, Rice, Curry, Quantity,CanteenNo) "
                    + "VALUES("+getActiveNsbmId()+",'"+date+"','"+Rice+"','"+Curry+"',"+Quantity+","+getActiveCanteenNo()+")");

        } 
        catch (SQLException ex) 
        {
           JOptionPane.showMessageDialog(null,"Invalid Entry\n(" + ex + ")");
        }
    }
     
//METHOD TO GET CANTEEN NUMBER ACCORDING TO CANTEEN NAME
    public void getCanteenNo()
    {
        if (!"Hostel Canteen".equals(getActiveCanteen()))
            setActiveCanteenNo(2);
        else {
            setActiveCanteenNo(1);
        }
    }
    
//METHOD TO ADD CART TABLE DATA TO ORDER TABLE
    public void forwardTable()
    {
        try {
            stmt = con.createStatement();
            stmt.execute("INSERT INTO orders(NSBMID, Date, Rice, Curry, Quantity, CanteenNo) "
                    + "SELECT (NSBMID), (Date), (Rice), (Curry), (Quantity), (CanteenNo)"
                    + "FROM cart");
        } 
        catch (NumberFormatException | SQLException ex)
        {
           JOptionPane.showMessageDialog(null,"Invalid Entry\n(" + ex + ")");
            
        }
    
    }

//METHOD TO VALIDATE A PASSWORD
    public int validatePassword(String tableName, String password)
    {
        try
        {
            stmt = con.createStatement();
            String SQL = "SELECT NSBMID FROM " + tableName + " WHERE Password = '" +password+"'";
            ResultSet rs = stmt.executeQuery(SQL);
            while(rs.next())
            {
                int value = rs.getInt("NSBMID");
                if(value == getActiveNsbmId())
                {
                    return 1;
                } 
       
            }
           
        }
        catch (NumberFormatException | SQLException ex) {
           JOptionPane.showMessageDialog(null,"Invalid Entry\n(" + ex + ")");
        }
        return 0;
    }
    
//METHODS TO INSERT OTHER ORDERS INTO OTHER ORDERS TABLE
    public void insertOOvalues(String item,String qty,String ddate)
    {
         try 
        {
            String odate = getDateStr();
            stmt = con.createStatement();
            stmt.execute("INSERT INTO otherorders(NSBMID, DDate, Item, Quantity,CanteenNo, ODate) "
                    + "VALUES("+getActiveNsbmId()+", '"+ddate+"', '"+item+"', "+parseInt(qty)+","+getActiveCanteenNo()+",'"+odate+"')");

        } 
       catch (NumberFormatException | SQLException ex) {
           JOptionPane.showMessageDialog(null,"Invalid Entry\n(" + ex + ")");
        }
         
    }
    public void insertOtherOrders(JCheckBox cb1,JCheckBox cb2, JCheckBox cb3, String qty1, String qty2, String qty3, String ddate)
    {
        
        if(cb1.isSelected())
        {
           insertOOvalues("Chocolate Icing Cake",qty1,ddate);
        }
        
        if(cb2.isSelected())
        {
           insertOOvalues("Strawberry Buttercream Cake",qty2,ddate);
        }
        
        if(cb3.isSelected())
        {
           insertOOvalues("Chocolate Caramel Cake",qty3,ddate);
        }
    }
    
//METHOD TO DISPLAY CART TABLE
    public void displayCartTable(JTable tableName) {  
     DefaultTableModel dm = new DefaultTableModel(0, 0);  
     String s[] = new String[]{"CartID", "Rice Type", "Curry", "Quantity", "NSBMID"};  
     dm.setColumnIdentifiers(s);  
     tableName.setModel(dm);  
     openConn(); 
       try {  
       PreparedStatement pst = con.prepareStatement("SELECT * FROM cart");  
       ResultSet rs = pst.executeQuery();  
       while (rs.next()) {  
           String CartID = rs.getString(1); 
           String Rice = rs.getString(4); 
           String Curry = rs.getString(5); 
           String Quantity = rs.getString(6);  
           String NSBMID = rs.getString(2); 
         Vector<String> vector = new Vector<>();   
         vector.add(CartID);  
         vector.add(Rice);  
         vector.add(Curry);  
         vector.add(Quantity); 
         vector.add(NSBMID); 
         dm.addRow(vector);  
       }  
       tableName.getColumnModel().getColumn(0).setPreferredWidth(40);
       tableName.getColumnModel().getColumn(1).setPreferredWidth(40);
       tableName.getColumnModel().getColumn(3).setPreferredWidth(20);
       tableName.getColumnModel().getColumn(4).setPreferredWidth(50);
       
     }catch (SQLException e)
        {
            JOptionPane.showMessageDialog(null,"Invalid Entry\n(" + e + ")");
        }
   }     

//GETTER METHOD TO GET ACTIVE NSBM ID
    public int getActiveNsbmId() {
        return activeNsbmId;
    }

//SETTER METHOD TO SET ACTIVE NSBM ID
    public void setActiveNsbmId(int activeNsbmId) {
        DatabaseClass.activeNsbmId = activeNsbmId;
    }

//GETTER METHOD TO GET ACTIVE CANTEEN
    public String getActiveCanteen() {
        return activeCanteen;
    }

//SETTER METHOD TO SET ACTIVE CANTEEN
    public void setActiveCanteen(String activeCanteen) {
        DatabaseClass.activeCanteen = activeCanteen;
    }

//GETTER METHOD TO GET ACTIVE CANTEEN NUMBER
    public int getActiveCanteenNo() {
        return activeCanteenNo;
    }

//SETTER METHOD TO SET ACTIVE CANTEEN NUMBER
    public void setActiveCanteenNo(int activeCanteenNo) {
        DatabaseClass.activeCanteenNo = activeCanteenNo;
    }
    

}

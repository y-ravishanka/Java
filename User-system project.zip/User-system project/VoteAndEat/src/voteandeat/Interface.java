
package voteandeat;

/**
 *
 * @NSBM FOOD ORDERING AND VOTING SYSTEM 
 */

//INTERFACE SET TO REMIND THE PROGRAMMER TO OVERRIDE MENTIONED METHODS
public interface Interface {
    
    public void home();
    public void vote();
    public void order();
    public void otherOrders();
    public void cancel();
}

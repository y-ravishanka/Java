
package voteandeat;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @NSBM FOOD ORDERING AND VOTING SYSTEM 
 */

public abstract class DateTimeConversions {
    
//METHOD TO GET SYSTEM DATE AS INT
     public int getDateInt(){
        int date=0;
        DateFormat df = new SimpleDateFormat("yyyyMMdd");
        Date dateobj = new Date();
        date= Integer.parseInt(df.format(dateobj));
        return date;
    }
  
//METHOD TO GET SYSTEM DATE AS STRING
    public String getDateStr(){
        String date;
        DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
        Date dateobj = new Date();
        date= df.format(dateobj);
        return date;
    }
    
//METHOD TO GET SYSTEM TIME AS STRING
    public String getTimeStr(){
        String time;
        DateFormat df = new SimpleDateFormat("HH:mm:ss");
        Date dateobj = new Date();
        time= df.format(dateobj);
        return time;
    }
    
//METHOD TO VALIDATE DATE FORMAT
   public static boolean validateDateFormat(String Date)
   {
	if (Date.trim().equals(""))
	{
	    return true;
	}

	else
	{

	    SimpleDateFormat sdfrmt = new SimpleDateFormat("yyyy/MM/dd");
	    sdfrmt.setLenient(false);
            //CHECKS WETHER THE DATE FORMAT IS ACCEPTABLE
	    try
	    {
	        Date checkDate = sdfrmt.parse(Date);
	    }

	    catch (ParseException e)
	    {
	        return false;
	    }
	    return true;
	}
   }
}

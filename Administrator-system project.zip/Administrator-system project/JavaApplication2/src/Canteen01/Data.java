/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Canteen01;

/**
 *
 * @NSBM FOOD ORDERING AND VOTING SYSTEM
 */
public class Data {
    private String name,nic,contnum;
    private String logindate,logintime,logouttime;
    private String orderid,nsbmid,rice,curry,quantity;
    private String soitems,sodate;
    private String date,fish,chicken,egg,veg,c1,c2,c3;
    private String sdate,f1,f2,f3,e1,e2,e3,c11,c12,c13,c21,c22,c23,c31,c32,c33;
    
    public Data(String name, String nic, String contnum) {
        this.name = name;
        this.nic = nic;
        this.contnum = contnum;
    }

    public Data(String nic, String logindate, String logintime, String logouttime) {
        this.nic = nic;
        this.logindate = logindate;
        this.logintime = logintime;
        this.logouttime = logouttime;
    }

    public Data(String orderid, String nsbmid, String rice, String curry, String quantity) {
        this.orderid = orderid;
        this.nsbmid = nsbmid;
        this.rice = rice;
        this.curry = curry;
        this.quantity = quantity;
    }
    
    public Data(String orderid, String nsbmid, String items, int quantity, String date) {
        this.orderid = orderid;
        this.nsbmid = nsbmid;
        this.soitems = items;
        this.quantity = String.valueOf(quantity);
        this.sodate = date;
    }

    public Data(String date, String fish, String chicken, String egg, String veg, String c1, String c2, String c3) {
        this.date = date;
        this.fish = fish;
        this.chicken = chicken;
        this.egg = egg;
        this.veg = veg;
        this.c1 = c1;
        this.c2 = c2;
        this.c3 = c3;
    }

    public Data(String orderid, String nsbmid, String rice, String curry, String quantity, String date) {
        this.orderid = orderid;
        this.nsbmid = nsbmid;
        this.rice = rice;
        this.curry = curry;
        this.quantity = quantity;
        this.date = date;
    }
    
    public Data(String orderid, String nsbmid, String items, int quantity, String date, String gdate) {
        this.orderid = orderid;
        this.nsbmid = nsbmid;
        this.soitems = items;
        this.quantity = String.valueOf(quantity);
        this.sodate = date;
        this.date = gdate;
    }
    
    public Data(String date, String sdate, String f1, String f2, String f3, String c1, String c2, String c3, String e1, String e2, String e3, String c11, String c12, String c13, String c21, String c22, String c23, String c31, String c32, String c33) {
        this.date = date;
        this.sdate = sdate;
        this.f1 = f1;
        this.f2 = f2;
        this.f3 = f3;
        this.c1 = c1;
        this.c2 = c2;
        this.c3 = c3;
        this.e1 = e1;
        this.e2 = e2;
        this.e3 = e3;
        this.c11 = c11;
        this.c12 = c12;
        this.c13 = c13;
        this.c21 = c21;
        this.c22 = c22;
        this.c23 = c23;
        this.c31 = c31;
        this.c32 = c32;
        this.c33 = c33;
    }

    public Data(String date, String f1, String f2, String f3, String c1, String c2, String c3, String e1, String e2, String e3, String c11, String c12, String c13, String c21, String c22, String c23, String c31, String c32, String c33) {
        this.date = date;
        this.c1 = c1;
        this.c2 = c2;
        this.c3 = c3;
        this.f1 = f1;
        this.f2 = f2;
        this.f3 = f3;
        this.e1 = e1;
        this.e2 = e2;
        this.e3 = e3;
        this.c11 = c11;
        this.c12 = c12;
        this.c13 = c13;
        this.c21 = c21;
        this.c22 = c22;
        this.c23 = c23;
        this.c31 = c31;
        this.c32 = c32;
        this.c33 = c33;
    }

    public String getSdate() {
        return sdate;
    }

    public String getF1() {
        return f1;
    }

    public String getF2() {
        return f2;
    }

    public String getF3() {
        return f3;
    }

    public String getE1() {
        return e1;
    }

    public String getE2() {
        return e2;
    }

    public String getE3() {
        return e3;
    }

    public String getC11() {
        return c11;
    }

    public String getC12() {
        return c12;
    }

    public String getC13() {
        return c13;
    }

    public String getC21() {
        return c21;
    }

    public String getC22() {
        return c22;
    }

    public String getC23() {
        return c23;
    }

    public String getC31() {
        return c31;
    }

    public String getC32() {
        return c32;
    }

    public String getC33() {
        return c33;
    }

    public String getDate() {
        return date;
    }

    public String getFish() {
        return fish;
    }

    public String getChicken() {
        return chicken;
    }

    public String getEgg() {
        return egg;
    }

    public String getVeg() {
        return veg;
    }

    public String getC1() {
        return c1;
    }

    public String getC2() {
        return c2;
    }

    public String getC3() {
        return c3;
    }

    public String getSoitems() {
        return soitems;
    }

    public String getSodate() {
        return sodate;
    }

    public String getLogindate() {
        return logindate;
    }

    public String getLogintime() {
        return logintime;
    }

    public String getLogouttime() {
        return logouttime;
    }

    public String getName() {
        return name;
    }

    public String getNic() {
        return nic;
    }

    public String getContnum() {
        return contnum;
    }

    public String getOrderid() {
        return orderid;
    }

    public String getNsbmid() {
        return nsbmid;
    }

    public String getRice() {
        return rice;
    }

    public String getCurry() {
        return curry;
    }

    public String getQuantity() {
        return quantity;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Canteen01;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.*;
import java.util.ArrayList;

/**
 *
 *@NSBM FOOD ORDERING AND VOTING SYSTEM
 */
public class SQLClass {
    
    Connection con=null;
    Statement stmt = null;
    PreparedStatement pstmt = null;
    private String conStr = "jdbc:mysql://localhost:3306/voteandordersystem";
    private String dbUname="root";
    //ASSIGN YOUR MYSQL PASSWORD BELOW
    private String dbPword="";
    private int canteen;
    private int i,j;
    
    private void setConnection(){
        try{
            con = DriverManager.getConnection(conStr, dbUname, dbPword);
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Please contact your Administrator and check your Database</body></html> ").setVisible(true);
        }
    }
    
    public void test(){
        try{
            setConnection();
            stmt = con.createStatement();
            String qur1 = ("SELECT * FROM user;");
            ResultSet rst = stmt.executeQuery(qur1);
            if(rst.next()){
                String id = rst.getString(1);
                String name = rst.getString(2);
                String pword = rst.getString(3);
                System.out.println("nsbm id: " + id);
                System.out.println("Name: " + name);
                System.out.println("password: " + pword);
            }
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
        }
        
    }
    
    public int[] checkLogin(String[] s1){
        int[] tmp = {0,0};
        String pword=null;
        int canteen=0;
        try{
            setConnection();
            String qur,qur2,qur3;
            ResultSet rst,rst2;
            qur="select * from admindetails where NIC = ?;";
            pstmt = con.prepareStatement(qur);
            pstmt.setString(1,s1[0]);
            rst = pstmt.executeQuery();
            while(rst.next()){
                pword = rst.getString("Password");
                if(pword.isEmpty()){
                    tmp[0]=0;
                }
                else{ 
                    if(pword.equals(s1[1])==true){
                        tmp[0]=1;
                    }
                    else{
                        tmp[0]=2;
                    }
                    canteen = Integer.parseInt(rst.getString("CanteenNo"));
                    if(canteen!=0){
                        tmp[1]=canteen;
                    }
                }
            }
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
            System.out.println(x);
        }
        return tmp;
    }
    
    public String[] getAdminMenu(int t1){
        String[] tmp = new String[7];
        Calculations s1 = new Calculations();
        try{
            setConnection();
            stmt = con.createStatement();
            String qur1,qur2,qur3;
            ResultSet rst1,rst2,rst3;
            qur1="select * from menuitems where (Date=?) and (CanteenNo=?);";
            pstmt = con.prepareStatement(qur1);
            pstmt.setString(1,s1.getDateStr());
            pstmt.setInt(2,t1);
            rst1 = pstmt.executeQuery();
            while(rst1.next()){
                tmp[0] = rst1.getString("Fish");
                tmp[1] = rst1.getString("Chicken");
                tmp[2] = rst1.getString("Egg");
                tmp[3] = rst1.getString("Curry01");
                tmp[4] = rst1.getString("Curry02");
                tmp[5] = rst1.getString("Curry03");
                tmp[6] = rst1.getString("Veg");
            }
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
        }
        return tmp;
    }
    
    public String[][] getCurryNames(String t1,int t2){
        String[][] tmp =new String[3][3];
        try{
            setConnection();
            String qur1,qur2,qur3;
            ResultSet rst,rst2,rst3;
            qur1="select * from votingmenu where (PrepDate=?) and (CanteenNo=?);";
            pstmt = con.prepareStatement(qur1);
            pstmt.setString(1,t1);
            pstmt.setInt(2, t2);
            rst = pstmt.executeQuery();
            while(rst.next()){
                tmp[0][0]=rst.getString("Opt11");
                tmp[0][1]=rst.getString("Opt12");
                tmp[0][2]=rst.getString("Opt13");
                
                tmp[1][0]=rst.getString("Opt21");
                tmp[1][1]=rst.getString("Opt22");
                tmp[1][2]=rst.getString("Opt23");
                
                tmp[2][0]=rst.getString("Opt31");
                tmp[2][1]=rst.getString("Opt32");
                tmp[2][2]=rst.getString("Opt33");
            }
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
        }
        return tmp;
    }
    
    public int[][] getVotingCount(String t1,int t2){
        int[][] tmp = new int[6][3];
        try{
            setConnection();
            String qur1,qur2,qur3;
            ResultSet rst,rst2,rst3;
            qur1="select * from votecount where (PrepDate=?) and (CanteenNo=?);";
            pstmt =con.prepareStatement(qur1);
            pstmt.setString(1,t1);
            pstmt.setInt(2,t2);
            rst = pstmt.executeQuery();
            while(rst.next()){
                tmp[0][0] = Integer.parseInt(rst.getString("Fish01"));
                tmp[0][1] = Integer.parseInt(rst.getString("Fish02"));
                tmp[0][2] = Integer.parseInt(rst.getString("Fish03"));
                
                tmp[1][0] = Integer.parseInt(rst.getString("Chicken01"));
                tmp[1][1] = Integer.parseInt(rst.getString("Chicken02"));
                tmp[1][2] = Integer.parseInt(rst.getString("Chicken03"));
                
                tmp[2][0] = Integer.parseInt(rst.getString("Egg01"));
                tmp[2][1] = Integer.parseInt(rst.getString("Egg02"));
                tmp[2][2] = Integer.parseInt(rst.getString("Egg03"));
                
                tmp[3][0] = Integer.parseInt(rst.getString("Opt11"));
                tmp[3][1] = Integer.parseInt(rst.getString("Opt12"));
                tmp[3][2] = Integer.parseInt(rst.getString("Opt13"));
                
                tmp[4][0] = Integer.parseInt(rst.getString("Opt21"));
                tmp[4][1] = Integer.parseInt(rst.getString("Opt22"));
                tmp[4][2] = Integer.parseInt(rst.getString("Opt23"));
                
                tmp[5][0] = Integer.parseInt(rst.getString("Opt31"));
                tmp[5][1] = Integer.parseInt(rst.getString("Opt32"));
                tmp[5][2] = Integer.parseInt(rst.getString("Opt33"));
            }
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
        }
        return tmp;
    }
    
    public int setAdmin(int[] t1,String[] s1){
        int tmp=0;
        try{
            setConnection();
            String qur1,qur2,qur3;
            ResultSet rst1,rst2,rst3;
            System.out.println("");
            qur1="insert into admindetails" + " values (?,?,?,?,?)";
            PreparedStatement preparedStmt = con.prepareStatement(qur1);
            preparedStmt.setString (1, s1[0]);
            preparedStmt.setInt (2, t1[0]);
            preparedStmt.setString   (3, s1[1]);
            preparedStmt.setInt (4, t1[1]);
            preparedStmt.setString    (5, s1[2]);

            // execute the preparedstatement
            preparedStmt.execute();
            
            tmp=1;
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
            tmp=0;
        }
        return tmp;
    }
    
    public int removeAdmin(String t1){
        int tmp=0;
        try{
            setConnection();
            String qur1,qur2,qur3;
            ResultSet rst1,rst2,rst3;
            qur1="delete from admindetails where NIC=(?);";
            pstmt = con.prepareCall(qur1);
            pstmt.setString(1,t1);
            pstmt.execute();
            tmp=1;
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
            tmp=0;
        }
        return tmp;
    }
    
    public int setVoting(int t1,String[] s1,String[][] s2,String[][] s3){
        int tmp=0;
        try{
            setConnection();
            String qur1,qur2,qur3;
            ResultSet rst1,rst2,rst3;
            qur1="insert into votingmenu" + " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
            pstmt = con.prepareStatement(qur1);
            
            pstmt.setString(1,s1[1]);
            pstmt.setString(2,s1[0]);
            
            pstmt.setInt(3,t1);
            
            pstmt.setString(4,s2[0][0]);
            pstmt.setString(5,s2[0][1]);
            pstmt.setString(6,s2[0][2]);
            
            pstmt.setString(7,s2[1][0]);
            pstmt.setString(8,s2[1][1]);
            pstmt.setString(9,s2[1][2]);
            
            pstmt.setString(10,s2[2][0]);
            pstmt.setString(11,s2[2][1]);
            pstmt.setString(12,s2[2][2]);
            
            pstmt.setString(13,s3[0][0]);
            pstmt.setString(14,s3[0][1]);
            pstmt.setString(15,s3[0][2]);
            
            pstmt.setString(16,s3[1][0]);
            pstmt.setString(17,s3[1][1]);
            pstmt.setString(18,s3[1][2]);
            
            pstmt.setString(19,s3[2][0]);
            pstmt.setString(20,s3[2][1]);
            pstmt.setString(21,s3[2][2]);
            
            pstmt.execute();
            tmp=1;
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
            tmp=0;
        }
        return tmp;
    }    
    
    public int insertMenu(int t3,String[] t1,String[] t2){
        int tmp=0;
        String[] s1 = new String[6];
        
        try{
            setConnection();
            String qur1,qur,qur3;
            ResultSet rst,rst2,rst3;
            qur="select * from votingmenu where PrepDate = ? and CanteenNo = ?;";
            System.out.println("menu run");
            pstmt = con.prepareStatement(qur);
            pstmt.setString(1,t2[1]);
            pstmt.setInt(2,t3);
            rst = pstmt.executeQuery();
            while(rst.next()){
                s1[0]=rst.getString(t1[0]);
                s1[1]=rst.getString(t1[1]);
                s1[2]=rst.getString(t1[2]);
                s1[3]=rst.getString(t1[3]);
                s1[4]=rst.getString(t1[4]);
                s1[5]=rst.getString(t1[5]);
            }
            qur="insert into menuitems"+" values (?,?,?,?,?,?,?,?,?);";
            pstmt =  con.prepareStatement(qur);
            pstmt.setString(1,t2[1]);
            pstmt.setInt(2,t3);
            pstmt.setString(3,s1[0]);
            pstmt.setString(4,s1[1]);
            pstmt.setString(5,s1[2]);
            pstmt.setString(6,t2[0]);
            pstmt.setString(7,s1[3]);
            pstmt.setString(8,s1[4]);
            pstmt.setString(9,s1[5]);
            pstmt.execute();
            tmp=1;
        }
        catch (Exception x){
            System.out.println(x);
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
            tmp=0;
        }
        
        return tmp;
    }
    
    public void loginDate(String s1,int t1){
        try{
            setConnection();
            Calculations f1 =new Calculations();
            String qur1,qur2,qur3;
            ResultSet rst1,rst2,rst3;
            qur1="insert into adminlogindetails (NIC, CanteenNo, LoginDate, LoginTime, LogoutTime)"+" values (?,?,?,?,?);";
            pstmt = con.prepareStatement(qur1);
            pstmt.setString(1,s1);
            pstmt.setInt(2,t1);
            pstmt.setString(3,f1.getDateStr());
            pstmt.setString(4,f1.getTimeStr());
            pstmt.setString(5,null);
            pstmt.execute();
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
        }
    }
    
    public void logoutTime(String s1,int t1){
        String s2 = takeLITime(s1,t1);
        try{
            setConnection();
            Calculations f1 =new Calculations();
            String qur1,qur2,qur3;
            ResultSet rst1,rst2,rst3;
            qur1="update adminlogindetails set LogoutTime = ? where (NIC = ?) and (CanteenNo = ?) and (LoginTime = ?);";
            pstmt = con.prepareStatement(qur1);
            pstmt.setString(1,f1.getTimeStr());
            pstmt.setString(2,s1);
            pstmt.setInt(3,t1);
            pstmt.setString(4,s2);
            pstmt.execute();
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
        }
    }
    
    private String takeLITime(String t1, int t2){
        String s1=null;
        try{
            setConnection();
            String qur1,qur2,qur3;
            ResultSet rst,rst2,rst3;
            qur1="select LoginTime from adminlogindetails where (NIC = ?) and (CanteenNo = ?) order by LoginTime desc limit 1;";
            pstmt = con.prepareStatement(qur1);
            pstmt.setString(1,t1);
            pstmt.setInt(2,t2);
            rst = pstmt.executeQuery();
            while(rst.next()){
                s1 = rst.getString("LoginTime");
            }
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
        }
        return s1;
    }
    
    public String[] order(int t1){
        String[] s1 = new String[9];
        int tmp=1;
        try{
            setConnection();
            Calculations o1 = new Calculations();
            String qur1,qur2,qur3;
            ResultSet rst,rst1,rst3;
            qur1="select * from orders where (Date = ?) and (CanteenNo = ?) and (Accept = 0) order by OrderID asc limit 1;";
            pstmt = con.prepareStatement(qur1);
            pstmt.setString(1,o1.getDateStr());
            pstmt.setInt(2,t1);
            rst = pstmt.executeQuery();
            while(rst.next()){
                s1[0] = String.valueOf(rst.getString("OrderID"));
                s1[1] = String.valueOf(rst.getString("NSBMID"));
                s1[2] = String.valueOf(rst.getString("Quantity"));
                s1[3] = rst.getString("Curry");
                s1[4] = rst.getString("Rice");
            }
            
            qur2="select * from menuitems where (Date = ?) and (CanteenNo = ?)";
            pstmt = con.prepareStatement(qur2);
            pstmt.setString(1,o1.getDateStr());
            pstmt.setInt(2,t1);
            rst1 = pstmt.executeQuery();
            while(rst1.next()){
                switch (s1[3]){
                    case "Fish and 3 Curries":
                        {s1[3] = "MealType - Fish";
                        s1[5] = rst1.getString("Fish");
                        break;}
                    case "Chicken and 3 Curries":
                        {s1[3] = "MealType - Chicken";
                        s1[5] = rst1.getString("Chicken");
                        break;}
                    case "Egg and 3 Curries":
                        s1[3] = "MealType - Egg";
                        s1[5] = rst1.getString("Egg");
                        break;
                    case "Vegetarian (4 Curries)":
                        {s1[3] = "MealType - Vegetarian";
                        s1[5] = rst1.getString("Veg");
                        break;}
                }

                s1[6] = rst1.getString("Curry01");
                s1[7] = rst1.getString("Curry02");
                s1[8] = rst1.getString("Curry03");
            }
            
        }
        catch (NullPointerException e){
            for(i=0;i<9;++i){
                s1[i]=null;
            }
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
            System.out.println(x);
        }
        return s1;
    }
    
    public String[] sorder(int t1){
        String[] s1 = new String[5];
        int tmp=1;
        try{
            setConnection();
            String qur1,qur2,qur3;
            ResultSet rst,rst2,rst3;
            qur1="select * from otherorders where (CanteenNo = ?) and (Accept = 0) order by ODate asc limit 1;";
            pstmt = con.prepareStatement(qur1);
            pstmt.setInt(1,t1);
            rst = pstmt.executeQuery();
            while(rst.next()){
                s1[0] = rst.getString("OOID");
                s1[1] = rst.getString("NSBMID");
                s1[2] = rst.getString("ODate");
                s1[3] = rst.getString("Quantity");
                s1[4] = rst.getString("Item");
            }
            
        }
        catch (NullPointerException e){
            for(i=0;i<5;++i){
                s1[i]=null;
            }
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
            System.out.println(x);
        }
        return s1;
    }
    
    public int updateOrder(int t1,int t2){
        int tmp=0;
        try{
            setConnection();
            String qur1,qur2,qur3;
            ResultSet rst1,rst2,rst3;
            qur1="update orders set Accept = ? where (OrderID = ?);";
            pstmt = con.prepareStatement(qur1);
            pstmt.setInt(1,t1);
            pstmt.setInt(2,t2);
            pstmt.execute();
            tmp=1;
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
            tmp=0;
        }
        return tmp;
    }
    
    public int updateSOrder(int t1,int t2){
        int tmp=0;
        try{
            setConnection();
            String qur1,qur2,qur3;
            ResultSet rst1,rst2,rst3;
            qur1="update otherorders set Accept = ? where (OOID = ?);";
            pstmt = con.prepareStatement(qur1);
            pstmt.setInt(1,t1);
            pstmt.setInt(2,t2);
            pstmt.execute();
            tmp=1;
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
            tmp=0;
        }
        return tmp;
    }
    
    public ArrayList tableAdminDetails(int t1){
        ArrayList<Data> a1 = new ArrayList<>();
        try{
            setConnection();
            String qur1,qur2,qur3;
            ResultSet rst1,rst2,rst3;
            qur1="select * from admindetails where CanteenNo = ?;";
            pstmt = con.prepareStatement(qur1);
            pstmt.setInt(1,t1);
            rst1 = pstmt.executeQuery();
            Data data;
            while(rst1.next()){
                data = new Data(rst1.getString("NIC"),rst1.getString("Name"),rst1.getString("ContactNo"));
                a1.add(data);
            }
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
        }
        return a1;
    }
    
    public ArrayList tableAdminLDetails(int t1){
        ArrayList<Data> a1 = new ArrayList<>();
        try{
            setConnection();
            String qur1,qur2,qur3;
            ResultSet rst,rst2,rst3;
            qur1="select * from adminlogindetails where CanteenNo = ?;";
            pstmt = con.prepareStatement(qur1);
            pstmt.setInt(1,t1);
            rst = pstmt.executeQuery();
            Data data;
            while(rst.next()){
                data = new Data(rst.getString("NIC"),rst.getString("LoginDate"),rst.getString("LoginTime"),rst.getString("LogoutTime"));
                a1.add(data);
            }
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
        }
        return a1;
    }
    
    public ArrayList tableOrder(int t1,int t2){
        ArrayList<Data> a1 = new ArrayList<>();
        String[] s1 = new String[5];
        try{
            setConnection();
            Calculations o1 = new Calculations();
            String qur1,qur2,qur3;
            ResultSet rst,rst1,rst3;
            qur1="select * from orders where (Date = ?) and (CanteenNo = ?) and (Accept = ?) order by OrderID asc;";
            pstmt = con.prepareStatement(qur1);
            pstmt.setString(1,o1.getDateStr());
            pstmt.setInt(2,t1);
            pstmt.setInt(3,t2);
            rst = pstmt.executeQuery();
            while(rst.next()){
                s1[0] = String.valueOf(rst.getString("OrderID"));
                s1[1] = String.valueOf(rst.getString("NSBMID"));
                s1[2] = String.valueOf(rst.getString("Quantity"));
                s1[3] = rst.getString("Curry");
                s1[4] = rst.getString("Rice");
                switch (s1[3]){
                    case "Fish and 3 Curries":
                        s1[3] = "Fish";
                        break;
                    case "Chicken and 3 Curries":
                        s1[3] = "Chicken";
                        break;
                    case "Egg and 3 Curries":
                        s1[3] = "Egg";
                        break;
                    case "Vegetarian (4 Curries)":
                        s1[3] = "Veg";
                        break;
                }
                Data data;
                data =new Data(s1[0],s1[1],s1[4],s1[3],s1[2]);
                a1.add(data);
            }
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
        }
        return a1;
    }
    
    public ArrayList tableSOrder(int t1, int t2){
        ArrayList<Data> a1 = new ArrayList<>();
        String[] s1 = new String[4];
        int tmp;
        try{
            setConnection();
            String qur1,qur2,qur3;
            ResultSet rst,rst2,rst3;
            qur1="select * from otherorders where (CanteenNo = ?) and (Accept = ?) order by ODate asc;";
            pstmt = con.prepareStatement(qur1);
            pstmt.setInt(1,t1);
            pstmt.setInt(2,t2);
            rst = pstmt.executeQuery();
            while(rst.next()){
                s1[0] = rst.getString("OOID");
                s1[1] = rst.getString("NSBMID");
                s1[2] = rst.getString("ODate");
                tmp = Integer.parseInt(rst.getString("Quantity"));
                s1[3] = rst.getString("Item");
                Data data;
                data = new Data(s1[0],s1[1],s1[3],tmp,s1[2]);
                a1.add(data);
            }
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
        }
        return a1;
    }
    
    public ArrayList tableSearchOrder(int t1,int t2,int t3){
        ArrayList<Data> a1 = new ArrayList<>();
        String[] s1 = new String[5];
        try{
            setConnection();
            Calculations o1 = new Calculations();
            String qur1,qur2,qur3;
            ResultSet rst,rst1,rst3;
            qur1="select * from orders where (Date = ?) and (CanteenNo = ?) and (Accept = ?) and (NSBMID = ?) order by OrderID asc;";
            pstmt = con.prepareStatement(qur1);
            pstmt.setString(1,o1.getDateStr());
            pstmt.setInt(2,t1);
            pstmt.setInt(3,t2);
            pstmt.setInt(4, t3);
            rst = pstmt.executeQuery();
            while(rst.next()){
                s1[0] = String.valueOf(rst.getString("OrderID"));
                s1[1] = String.valueOf(rst.getString("NSBMID"));
                s1[2] = String.valueOf(rst.getString("Quantity"));
                s1[3] = rst.getString("Curry");
                s1[4] = rst.getString("Rice");
                switch (s1[3]){
                    case "Fish and 3 Curries":
                        s1[3] = "Fish";
                        break;
                    case "Chicken and 3 Curries":
                        s1[3] = "Chicken";
                        break;
                    case "Egg and 3 Curries":
                        s1[3] = "Egg";
                        break;
                    case "Vegetarian (4 Curries)":
                        s1[3] = "Veg";
                        break;
                }
                Data data;
                data =new Data(s1[0],s1[1],s1[4],s1[3],s1[2]);
                a1.add(data);
            }
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
            System.out.println(x);
        }
        return a1;
    }
    
    public ArrayList tableSearchSOrder(int t1, int t2, int t3){
        ArrayList<Data> a1 = new ArrayList<>();
        String[] s1 = new String[4];
        int tmp;
        try{
            setConnection();
            String qur1,qur2,qur3;
            ResultSet rst,rst2,rst3;
            qur1="select * from otherorders where (CanteenNo = ?) and (Accept = ?) and (NSBMID = ?) order by ODate asc;";
            pstmt = con.prepareStatement(qur1);
            pstmt.setInt(1,t1);
            pstmt.setInt(2,t2);
            pstmt.setInt(3,t3);
            rst = pstmt.executeQuery();
            while(rst.next()){
                s1[0] = rst.getString("OOID");
                s1[1] = rst.getString("NSBMID");
                s1[2] = rst.getString("ODate");
                tmp = Integer.parseInt(rst.getString("Quantity"));
                s1[3] = rst.getString("Item");
                Data data;
                data = new Data(s1[0],s1[1],s1[3],tmp,s1[2]);
                a1.add(data);
            }
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
            System.out.println(x);
        }
        return a1;
    }
    
    public int checkNIC(String s1){
        int tmp=0;
        try{
            setConnection();
            String qur,qur2,qur3;
            ResultSet rst,rst2,rst3;
            qur="select * from admindetails where NIC = ?;";
            pstmt = con.prepareStatement(qur);
            pstmt.setString(1,s1);
            rst = pstmt.executeQuery();
            if(rst.next()){
                String id = rst.getString("NIC");
                if(id.isEmpty()==true){
                    tmp=0;
                }
                else{
                    tmp=1;
                }
            }
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
            System.out.println(x);
        }
        return tmp;
    }
    
    public int resetPassword(String s1,String s2){
        int tmp=0;
        try{
            setConnection();
            String qur,qur2,qur3;
            ResultSet rst,rst2,rst3;
            qur="update admindetails set Password = ? where NIC = ?;";
            pstmt = con.prepareStatement(qur);
            pstmt.setString(1,s2);
            pstmt.setString(2,s1);
            pstmt.execute();
            tmp=1;
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
        }
        return tmp;
    }
    
    public ArrayList getTableMenu(int t1){
        ArrayList<Data> a1 = new ArrayList<>();
        String[] s1 = new String[8];
        try{
            setConnection();
            String qur1,qur2,qur3;
            ResultSet rst,rst2,rst3;
            qur1="select * from menuitems where CanteenNo = ? order by Date desc;";
            pstmt = con.prepareStatement(qur1);
            pstmt.setInt(1,t1);
            rst = pstmt.executeQuery();
            while(rst.next()){
                s1[0] = rst.getString("Date");
                s1[1] = rst.getString("Fish");
                s1[2] = rst.getString("Chicken");
                s1[3] = rst.getString("Egg");
                s1[4] = rst.getString("Veg");
                s1[5] = rst.getString("Curry01");
                s1[6] = rst.getString("Curry02");
                s1[7] = rst.getString("Curry03");
                Data data;
                data = new Data(s1[0],s1[1],s1[2],s1[3],s1[4],s1[5],s1[6],s1[7]);
                a1.add(data);
            }
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
            System.out.println(x);
        }
        return a1;
    }
    
    public ArrayList getTableOrder(int t1,int t2){
        ArrayList<Data> a1 = new ArrayList<>();
        String[] s1 = new String[6];
        try{
            setConnection();
            Calculations o1 = new Calculations();
            String qur1,qur2,qur3;
            ResultSet rst,rst1,rst3;
            qur1="select * from orders where (CanteenNo = ?) and (Accept = ?) order by Date desc;";
            pstmt = con.prepareStatement(qur1);
            pstmt.setInt(1,t1);
            pstmt.setInt(2,t2);
            rst = pstmt.executeQuery();
            while(rst.next()){
                s1[0] = String.valueOf(rst.getString("OrderID"));
                s1[1] = String.valueOf(rst.getString("NSBMID"));
                s1[2] = String.valueOf(rst.getString("Quantity"));
                s1[3] = rst.getString("Curry");
                s1[4] = rst.getString("Rice");
                s1[5] = rst.getString("Date");
                switch (s1[3]){
                    case "Fish and 3 Curries":
                        s1[3] = "Fish";
                        break;
                    case "Chicken and 3 Curries":
                        s1[3] = "Chicken";
                        break;
                    case "Egg and 3 Curries":
                        s1[3] = "Egg";
                        break;
                    case "Vegetarian (4 Curries)":
                        s1[3] = "Veg";
                        break;
                }
                Data data;
                data =new Data(s1[0],s1[1],s1[4],s1[3],s1[2],s1[5]);
                a1.add(data);
            }
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
        }
        return a1;
    }
    
    public ArrayList getTableSOrder(int t1, int t2){
        ArrayList<Data> a1 = new ArrayList<>();
        String[] s1 = new String[5];
        int tmp;
        try{
            setConnection();
            String qur1,qur2,qur3;
            ResultSet rst,rst2,rst3;
            qur1="select * from otherorders where (CanteenNo = ?) and (Accept = ?) order by ODate desc, DDate desc;";
            pstmt = con.prepareStatement(qur1);
            pstmt.setInt(1,t1);
            pstmt.setInt(2,t2);
            rst = pstmt.executeQuery();
            while(rst.next()){
                s1[0] = rst.getString("OOID");
                s1[1] = rst.getString("NSBMID");
                s1[2] = rst.getString("ODate");
                tmp = Integer.parseInt(rst.getString("Quantity"));
                s1[3] = rst.getString("Item");
                s1[4] = rst.getString("DDate");
                Data data;
                data = new Data(s1[0],s1[1],s1[3],tmp,s1[2],s1[4]);
                a1.add(data);
            }
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
        }
        return a1;
    }
    
    public ArrayList getTableMealProcess(int t1){
        ArrayList<Data> a1 = new ArrayList<>();
        String[] s1 = new String[20];
        int tmp;
        try{
            setConnection();
            String qur1,qur2,qur3;
            ResultSet rst,rst2,rst3;
            qur1="select * from votingmenu where (CanteenNo = ?) order by PrepDate desc;";
            pstmt = con.prepareStatement(qur1);
            pstmt.setInt(1,t1);
            rst = pstmt.executeQuery();
            while(rst.next()){
                s1[0] = rst.getString("PrepDate");
                s1[1] = rst.getString("ShowDate");
                
                s1[2] = rst.getString("Fish01");
                s1[3] = rst.getString("Fish02");
                s1[4] = rst.getString("Fish03");
                
                s1[5] = rst.getString("Chicken01");
                s1[6] = rst.getString("Chicken02");
                s1[7] = rst.getString("Chicken03");
                
                s1[8] = rst.getString("Egg01");
                s1[9] = rst.getString("Egg02");
                s1[10] = rst.getString("Egg03");
                
                s1[11] = rst.getString("Opt11");
                s1[12] = rst.getString("Opt12");
                s1[13] = rst.getString("Opt13");
                
                s1[14] = rst.getString("Opt21");
                s1[15] = rst.getString("Opt22");
                s1[16] = rst.getString("Opt23");
                
                s1[17] = rst.getString("Opt31");
                s1[18] = rst.getString("Opt32");
                s1[19] = rst.getString("Opt33");
                
                Data data;
                data = new Data(s1[0],s1[1],s1[2],s1[3],s1[4],s1[5],s1[6],s1[7],s1[8],s1[9],s1[10],s1[11],s1[12],s1[13],s1[14],s1[15],s1[16],s1[17],s1[18],s1[19]);
                a1.add(data);
            }
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
        }
        return a1;
    }
    
    public ArrayList getTableVoteCount(int t1){
        ArrayList<Data> a1 = new ArrayList<>();
        String[] s1 = new String[20];
        int tmp;
        try{
            setConnection();
            String qur1,qur2,qur3;
            ResultSet rst,rst2,rst3;
            qur1="select * from votecount where (CanteenNo = ?) order by PrepDate desc;";
            pstmt = con.prepareStatement(qur1);
            pstmt.setInt(1,t1);
            rst = pstmt.executeQuery();
            while(rst.next()){
                s1[0] = rst.getString("PrepDate");
                s1[1] = rst.getString("Opt33");
                
                s1[2] = rst.getString("Fish01");
                s1[3] = rst.getString("Fish02");
                s1[4] = rst.getString("Fish03");
                
                s1[5] = rst.getString("Chicken01");
                s1[6] = rst.getString("Chicken02");
                s1[7] = rst.getString("Chicken03");
                
                s1[8] = rst.getString("Egg01");
                s1[9] = rst.getString("Egg02");
                s1[10] = rst.getString("Egg03");
                
                s1[11] = rst.getString("Opt11");
                s1[12] = rst.getString("Opt12");
                s1[13] = rst.getString("Opt13");
                
                s1[14] = rst.getString("Opt21");
                s1[15] = rst.getString("Opt22");
                s1[16] = rst.getString("Opt23");
                
                s1[17] = rst.getString("Opt31");
                s1[18] = rst.getString("Opt32");
                
                Data data;
                data = new Data(s1[0],s1[2],s1[3],s1[4],s1[5],s1[6],s1[7],s1[8],s1[9],s1[10],s1[11],s1[12],s1[13],s1[14],s1[15],s1[16],s1[17],s1[18],s1[1]);
                a1.add(data);
            }
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
        }
        return a1;
    }
    
    public int updateVoteMenu(String s1,String s2,String s3, int t1){
        int tmp=0;
        try{
            setConnection();
            stmt = con.createStatement();
            String qur,qur1,qur3;
            ResultSet rst,rst2,rst3;
            qur1 = "update votingmenu set "+s1+" = '"+s2+"' where (PrepDate = '"+s3+"') and (CanteenNo = "+t1+");";
            stmt.execute(qur1);
            tmp=1;
            
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
            System.out.println(x);
        }
        return tmp;
    }
    
    public String[] getMenu(int t1, String s1){
        String[] tmp = new String[7];
        try{
            setConnection();
            stmt = con.createStatement();
            String qur1,qur2,qur3;
            ResultSet rst1,rst2,rst3;
            qur1="select * from menuitems where (Date=?) and (CanteenNo=?);";
            pstmt = con.prepareStatement(qur1);
            pstmt.setString(1,s1);
            pstmt.setInt(2,t1);
            rst1 = pstmt.executeQuery();
            while(rst1.next()){
                tmp[0] = rst1.getString("Fish");
                tmp[1] = rst1.getString("Chicken");
                tmp[2] = rst1.getString("Egg");
                tmp[3] = rst1.getString("Curry01");
                tmp[4] = rst1.getString("Curry02");
                tmp[5] = rst1.getString("Curry03");
                tmp[6] = rst1.getString("Veg");
            }
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
        }
        return tmp;
    }
    
    public int updateMenu(String s1,String s2,String s3, int t1){
        int tmp=0;
        try{
            setConnection();
            stmt = con.createStatement();
            String qur,qur1,qur3;
            ResultSet rst,rst2,rst3;
            qur1 = "update menuitems set "+s1+" = '"+s2+"' where (Date = '"+s3+"') and (CanteenNo = "+t1+");";
            stmt.execute(qur1);
            tmp=1;
            
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
            System.out.println(x);
        }
        return tmp;
    }
    
    private void dump(){
        try{
            setConnection();
            stmt = con.createStatement();
            String qur1,qur2,qur3;
            ResultSet rst1,rst2,rst3;
            qur1=";";
            rst1 = stmt.executeQuery(qur1);
            if(rst1.next()){
                String id = rst1.getString(1);
                String name = rst1.getString(2);
                String pword = rst1.getString(3);
            }
        }
        catch (Exception x){
            new Massage("<html><body>Something went wrong !!!<br>Query Error !!!</body></html> ").setVisible(true);
        }
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Canteen01;

/**
 *
 * @NSBM FOOD ORDERING AND VOTING SYSTEM
 */
public class SuperAdminLogin {
    private final String sUname="admin";
    private final String sPword="admin";

    public String getsUname() {
        return sUname;
    }

    public String getsPword() {
        return sPword;
    }
    
    
}
